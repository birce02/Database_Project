// assets/js/config.js
const API_BASE_URL = "https://localhost:7267/api";