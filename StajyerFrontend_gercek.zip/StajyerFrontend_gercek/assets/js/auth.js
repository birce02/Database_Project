// assets/js/auth.js

const TOKEN_KEY = "authToken";
const USER_EMAIL_KEY = "userEmail";
const USER_NAME_KEY = "username";
const USER_ROLE_KEY = "userRole"; // Yeni anahtar eklendi

function isTokenExpired(token) {
    if (!token) return true;
    try {
        const base64Url = token.split('.')[1];
        const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
        const jsonPayload = decodeURIComponent(window.atob(base64).split('').map(function(c) {
            return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
        }).join(''));

        const { exp } = JSON.parse(jsonPayload);
        return (Date.now() >= exp * 1000);
    } catch (e) { return true; }
}

function requireAuth() {
    const token = localStorage.getItem(TOKEN_KEY);
    if (!token || isTokenExpired(token)) {
        forceLogout();
    }
}

function saveLoginData(token, email, username, role) { // role parametresi eklendi
    localStorage.clear();
    localStorage.setItem(TOKEN_KEY, token);
    if(email) localStorage.setItem(USER_EMAIL_KEY, email);
    if(username) localStorage.setItem(USER_NAME_KEY, username);
    if(role) localStorage.setItem(USER_ROLE_KEY, role); // Rol kaydediliyor [cite: 2025-12-20]
}

function forceLogout() {
    localStorage.clear(); 
    window.location.href = "index.html";
}

function getAuthToken() {
    return localStorage.getItem(TOKEN_KEY);
}

async function fetchAuth(endpoint, options = {}) {
    const url = endpoint.startsWith("http") ? endpoint : `${API_BASE_URL}/${endpoint}`;
    const token = getAuthToken();

    const headers = {
        'Content-Type': 'application/json',
        ...options.headers
    };

    if (token) {
        headers['Authorization'] = `Bearer ${token}`;
    }

    const config = { ...options, headers: headers };

    try {
        const response = await fetch(url, config);
        if (response.status === 401) {
            forceLogout();
            return null;
        }
        return response;
    } catch (error) {
        console.error("API Hatası:", error);
        throw error;
    }
}