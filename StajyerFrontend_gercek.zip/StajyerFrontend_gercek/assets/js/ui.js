// assets/js/ui.js

// 1. Gerekli Kütüphaneleri Yükle
const libs = [
    "https://cdn.jsdelivr.net/npm/sweetalert2@11",
    "https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js",
    "https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.29/jspdf.plugin.autotable.min.js"
];

libs.forEach(src => {
    if (!document.querySelector(`script[src="${src}"]`)) {
        const script = document.createElement('script');
        script.src = src;
        document.head.appendChild(script);
    }
});

// 2. Loading Stilleri
const style = document.createElement('style');
style.innerHTML = `
    #loading-overlay {
        position: fixed; top: 0; left: 0; width: 100%; height: 100%;
        background: rgba(255, 255, 255, 0.7); backdrop-filter: blur(4px);
        z-index: 9999; display: none; justify-content: center; align-items: center; flex-direction: column;
    }
    .spinner {
        width: 50px; height: 50px; border: 5px solid #f3f3f3; border-top: 5px solid #0d6efd;
        border-radius: 50%; animation: spin 1s linear infinite;
    }
    @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
`;
document.head.appendChild(style);

function injectLoader() {
    if (!document.getElementById("loading-overlay")) {
        const loader = document.createElement("div");
        loader.id = "loading-overlay";
        loader.innerHTML = `<div class="spinner"></div><h5 class="mt-3 text-muted fw-bold">İşlem Yapılıyor...</h5>`;
        document.body.appendChild(loader);
    }
}
if (document.readyState === 'loading') document.addEventListener("DOMContentLoaded", injectLoader);
else injectLoader();

// --- TÜRKÇE KARAKTER DÜZELTİCİ (PDF İÇİN) ---
const trFix = (text) => {
    if (!text) return "";
    const trMap = { 'ğ':'g', 'Ğ':'G', 'ü':'u', 'Ü':'U', 'ş':'s', 'Ş':'S', 'ı':'i', 'İ':'I', 'ö':'o', 'Ö':'O', 'ç':'c', 'Ç':'C' };
    return String(text).replace(/[ğĞüÜşŞıİöÖçÇ]/g, (char) => trMap[char]);
};

// --- UI NESNESİ ---
const UI = {
    showLoading: () => { const l = document.getElementById("loading-overlay"); if(l) l.style.display = "flex"; },
    hideLoading: () => { const l = document.getElementById("loading-overlay"); if(l) l.style.display = "none"; },

    success: (message, title = 'Başarılı!') => {
        UI.hideLoading();
        Swal.fire({ icon: 'success', title: title, text: message, timer: 2000, showConfirmButton: false });
    },
    error: (message, title = 'Hata!') => {
        UI.hideLoading();
        Swal.fire({ icon: 'error', title: title, text: message, confirmButtonText: 'Tamam' });
    },
    warning: (message, title = 'Dikkat') => {
        UI.hideLoading();
        Swal.fire({ icon: 'warning', title: title, text: message, confirmButtonText: 'Tamam' });
    },
    toast: (title, icon = 'success') => {
        const Toast = Swal.mixin({
            toast: true, position: 'top-end', showConfirmButton: false, timer: 3000, timerProgressBar: true,
            didOpen: (toast) => { toast.addEventListener('mouseenter', Swal.stopTimer); toast.addEventListener('mouseleave', Swal.resumeTimer); }
        });
        Toast.fire({ icon: icon, title: title });
    },
    confirm: async (title, text, confirmButtonText = 'Evet, Sil!') => {
        const result = await Swal.fire({
            title: title, text: text, icon: 'warning', showCancelButton: true,
            confirmButtonColor: '#d33', cancelButtonColor: '#3085d6',
            confirmButtonText: confirmButtonText, cancelButtonText: 'İptal'
        });
        return result.isConfirmed;
    },

    // --- GENEL TABLO PDF İNDİRME ---
    exportTableToPDF: (tableId, title) => {
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();
        
        // Başlık
        doc.setFontSize(14);
        doc.text(trFix(title + " Raporu"), 14, 15);
        
        doc.autoTable({ 
            html: '#' + tableId,
            startY: 20,
            theme: 'grid',
            styles: { font: 'helvetica', fontSize: 8 },
            didParseCell: function (data) {
                // Türkçe karakterleri düzelt
                if (data.cell.text) {
                    data.cell.text = data.cell.text.map(t => trFix(t));
                }
                // Son sütunu (İşlemler) sil
                if (data.column.index === data.table.columns.length - 1) {
                    data.cell.text = ""; 
                }
            }
        });
        doc.save(`${title}_Raporu.pdf`);
    },

    // --- ÖZEL ZİMMET TUTANAĞI (GÜNCELLENDİ) ---
    createZimmetTutanagi: (assigneeName, itemCode) => {
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();

        // Verileri Türkçe karakterlerden arındır (Font hatası almamak için)
        const safeName = trFix(assigneeName);
        const safeCode = trFix(itemCode);
        const date = new Date().toLocaleDateString('tr-TR');

        // Başlık
        doc.setFontSize(18);
        doc.setFont("helvetica", "bold");
        doc.text("ZIMMET TESLIM TUTANAGI", 105, 20, null, null, "center");
        
        // Tarih
        doc.setFontSize(10);
        doc.setFont("helvetica", "normal");
        doc.text(`Tarih: ${date}`, 160, 30);

        // Metin
        doc.setFontSize(12);
        const text = `Asagida ozellikleri belirtilen demirbas, sirketimiz personeli/stajyeri \n${safeName} tarafindan saglam ve calisir vaziyette teslim alinmistir.`;
        doc.text(text, 14, 40);

        // Tablo
        doc.autoTable({
            startY: 60,
            head: [['Urun Kodu', 'Durum', 'Teslim Tarihi']],
            body: [[safeCode, "Calisir Durumda", date]],
            theme: 'striped'
        });

        // İmzalar
        const finalY = doc.lastAutoTable.finalY + 40;
        
        doc.setFontSize(11);
        doc.text("Teslim Eden (Yetkili)", 40, finalY);
        doc.text(".......................", 40, finalY + 10);
        
        doc.text("Teslim Alan (Personel)", 140, finalY);
        doc.text(".......................", 140, finalY + 10);
        doc.text(safeName, 140, finalY + 15);

        doc.save(`Zimmet_Tutanagi_${safeCode}.pdf`);
    }
};