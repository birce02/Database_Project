// assets/js/signalr-manager.js

// Backend Portunu Buraya Yaz (Senin portun 7267 idi)
const HUB_URL = "https://localhost:7267/hubs/inventory";

let connection = null;

async function startSignalR() {
    const token = localStorage.getItem("authToken");
    
    // Eğer giriş yapılmamışsa (Token yoksa) SignalR'ı başlatma
    if (!token) return;

    // 1. Bağlantı Ayarları
    connection = new signalR.HubConnectionBuilder()
        .withUrl(HUB_URL, {
            // Backend'deki [Authorize] kilidini açmak için Token gönderiyoruz
            accessTokenFactory: () => localStorage.getItem("authToken")
        })
        .withAutomaticReconnect() // Bağlantı koparsa kendi kendine tekrar dener
        .build();

    // ----------------------------------------------------
    // 2. EVENTLERİ DİNLEME (Backend'den Gelen Emirler)
    // ----------------------------------------------------

    // A. BİLDİRİM GELDİĞİNDE (Sağ Üst Köşe)
    connection.on("ReceiveNotification", (message, type) => {
        if (typeof UI !== 'undefined' && UI.toast) {
            UI.toast(message, type);
        } else {
            console.log("🔔 BİLDİRİM:", message);
        }
    });

    // B. DASHBOARD GÜNCELLEMESİ GELDİĞİNDE
    connection.on("ReceiveDashboardUpdate", () => {
        console.log("⚡ Dashboard verileri yenileniyor...");
        if (typeof loadDashboardStats === 'function') {
            loadDashboardStats();
        }
    });

    // C. TABLO/LİSTE GÜNCELLEMESİ GELDİĞİNDE
    connection.on("ReceiveEntityUpdate", (entityName) => {
        console.log(`⚡ ${entityName} listesi için güncelleme geldi.`);

        // Envanter Tablosu
        if (entityName === "Inventory" && typeof loadInventory === 'function') {
            loadInventory();
        }
        
        // Zimmet Tablosu
        if (entityName === "Assignment" && typeof loadAssignments === 'function') {
            loadAssignments();
        }
        
        // Personel Tablosu
        if (entityName === "Employee" && typeof loadEmployees === 'function') {
            loadEmployees();
        }

        // --- EKSİK OLAN KISIM BURASIYDI (EKLENDİ) ---
        // Stajyer Tablosu
        if (entityName === "Intern" && typeof loadInterns === 'function') {
            loadInterns();
        }

        // Bakım Tablosu
        if (entityName === "Maintenance" && typeof loadMaintenance === 'function') {
            loadMaintenance();
        }
    });

    // ----------------------------------------------------
    // 3. BAĞLANTIYI BAŞLAT
    // ----------------------------------------------------
    try {
        await connection.start();
        console.log("🟢 SignalR Bağlantısı Kuruldu!");
    } catch (err) {
        console.error("🔴 SignalR Hatası:", err);
    }
}

// Sayfa tamamen yüklendiğinde SignalR'ı çalıştır
document.addEventListener("DOMContentLoaded", startSignalR);