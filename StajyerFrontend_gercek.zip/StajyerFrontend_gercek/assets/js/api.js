// Token'ı localStorage'dan al
function getAuthToken() {
    return localStorage.getItem("authToken");
}

// Backend'e istek atan ana fonksiyon
async function fetchAuth(endpoint, options = {}) {
    // 1. URL Hazırla (config.js'deki API_BASE_URL kullanılır)
    // Eğer endpoint zaten "http" ile başlıyorsa dokunma, değilse başına base url ekle
    const url = endpoint.startsWith("http") ? endpoint : `${API_BASE_URL}/${endpoint}`;

    // 2. Token'ı al
    const token = getAuthToken();

    // 3. Header'ları hazırla
    const headers = {
        'Content-Type': 'application/json',
        ...options.headers
    };

    // 4. Token varsa Header'a ekle (Bearer Token)
    if (token) {
        headers['Authorization'] = `Bearer ${token}`;
    }

    const config = {
        ...options,
        headers: headers
    };

    try {
        // 5. İsteği Yap
        const response = await fetch(url, config);

        // 6. Eğer 401 (Yetkisiz) gelirse -> Oturum düşmüş, çıkış yap
        if (response.status === 401) {
            console.warn("Oturum süresi doldu veya yetkisiz erişim.");
            localStorage.removeItem("authToken");
            window.location.href = "index.html";
            return null; // İşlemi durdur
        }

        return response;
    } catch (error) {
        console.error("API Bağlantı Hatası:", error);
        throw error; // Hatayı dashboard yakalasın diye fırlat
    }
}