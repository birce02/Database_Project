﻿using Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;

namespace Infrastructure.Configurations
{
    public class UniversityConfiguration : IEntityTypeConfiguration<University>
    {
        public void Configure(EntityTypeBuilder<University> builder)
        {
            builder.ToTable("Universities");

            builder.HasKey(u => u.Id);

            builder.Property(u => u.Name)
                   .IsRequired()
                   .HasMaxLength(250);

            // GÜNCELLEME 1: Üniversite isimleri için Unique Index eklemek performansı ve veri tutarlılığını artırır.
            builder.HasIndex(u => u.Name).IsUnique();

            // GÜNCELLEME 2: Seed Data eklerken CreatedAt ve IsDeleted gibi zorunlu (NOT NULL) alanları belirtiyoruz.
            builder.HasData(
                new University
                {
                    Id = 1,
                    Name = "Eskişehir Osmangazi Üniversitesi",
                    CreatedAt = DateTime.UtcNow,
                    IsDeleted = false
                }
            );

            // GÜNCELLEME 3: Soft delete filtresini buraya da ekliyoruz.
            builder.HasQueryFilter(u => !u.IsDeleted);
        }
    }
}