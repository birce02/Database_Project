﻿using Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Infrastructure.Configurations
{
    public class MaintenanceConfiguration : IEntityTypeConfiguration<Maintenance>
    {
        public void Configure(EntityTypeBuilder<Maintenance> builder)
        {
            builder.ToTable("Maintenances");

            builder.HasKey(m => m.Id);

            // GÜNCELLEME 1: PostgreSQL 'now()' yerine SQL Server 'GETUTCDATE()'
            builder.Property(m => m.ReportedAt)
                   .HasDefaultValueSql("GETUTCDATE()");

            // GÜNCELLEME 2: 'timestamptz' yerine 'datetime2'
            builder.Property(m => m.RepairedAt)
                   .HasColumnType("datetime2");

            builder.Property(m => m.Description).HasMaxLength(2000);

            // GÜNCELLEME 3: Konsolda aldığın "decimal precision" uyarısını giderir
            // (18 basamaklı sayı, virgülden sonra 2 basamak)
            builder.Property(m => m.Cost)
                   .HasPrecision(18, 2);

            builder.HasOne(m => m.InventoryItem)
                   .WithMany(i => i.Maintenances)
                   .HasForeignKey(m => m.InventoryItemId)
                   .OnDelete(DeleteBehavior.Cascade);

            builder.HasIndex(m => m.InventoryItemId);

            // GÜNCELLEME 4: Soft delete (IsDeleted) filtresini buraya da ekliyoruz
            builder.HasQueryFilter(m => !m.IsDeleted);
        }
    }
}