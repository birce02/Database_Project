﻿using Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Infrastructure.Configurations
{
    public class AssignmentConfiguration : IEntityTypeConfiguration<Assignment>
    {
        public void Configure(EntityTypeBuilder<Assignment> builder)
        {
            builder.ToTable("Assignments", t =>
            {
                // GÜNCELLEME 1: SQL Server'da tırnak işaretleri (") yerine köşeli parantez ([]) kullanılır.
                t.HasCheckConstraint("CK_Assignments_Assignee",
                    "([InternId] IS NOT NULL AND [EmployeeId] IS NULL) OR ([InternId] IS NULL AND [EmployeeId] IS NOT NULL)");
            });

            builder.HasKey(a => a.Id);

            // GÜNCELLEME 2: PostgreSQL'deki 'now() at time zone 'utc'' yerine 
            // SQL Server'ın standart UTC fonksiyonu olan 'GETUTCDATE()' kullanılır.
            builder.Property(a => a.AssignedAt)
                    .HasDefaultValueSql("GETUTCDATE()");

            // GÜNCELLEME 3: timestamptz yerine datetime2
            builder.Property(a => a.ActualReturnAt)
                    .HasColumnType("datetime2");

            builder.HasOne(a => a.InventoryItem)
                    .WithMany(i => i.Assignments)
                    .HasForeignKey(a => a.InventoryItemId)
                    .OnDelete(DeleteBehavior.Restrict);

            builder.HasOne(a => a.Intern)
                    .WithMany(s => s.Assignments)
                    .HasForeignKey(a => a.InternId)
                    .OnDelete(DeleteBehavior.Restrict);

            builder.HasOne(a => a.Employee)
                    .WithMany(e => e.Assignments)
                    .HasForeignKey(a => a.EmployeeId)
                    .OnDelete(DeleteBehavior.SetNull);

            // GÜNCELLEME 4: Eğer daha önce InventoryItem'da yaptığımız gibi Soft Delete varsa:
            builder.HasQueryFilter(a => !a.IsDeleted);
        }
    }
}