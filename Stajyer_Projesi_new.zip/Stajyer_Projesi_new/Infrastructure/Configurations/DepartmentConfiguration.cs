﻿using Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;

namespace Infrastructure.Configurations
{
    public class DepartmentConfiguration : IEntityTypeConfiguration<Department>
    {
        public void Configure(EntityTypeBuilder<Department> builder)
        {
            builder.ToTable("Departments");

            builder.HasKey(d => d.Id);

            builder.Property(d => d.Name)
                   .IsRequired()
                   .HasMaxLength(100);

            // SQL Server'da Name kolonu için unique index
            builder.HasIndex(d => d.Name).IsUnique();

            // SQL Server'da Seed Data eklerken, BaseEntity'den gelen 
            // CreatedAt gibi NOT NULL alanları da eklemek migration hatalarını önler.
            builder.HasData(
                new Department { Id = 1, Name = "Frontend", CreatedAt = DateTime.UtcNow, IsDeleted = false },
                new Department { Id = 2, Name = "Backend", CreatedAt = DateTime.UtcNow, IsDeleted = false },
                new Department { Id = 3, Name = "Mobile", CreatedAt = DateTime.UtcNow, IsDeleted = false },
                new Department { Id = 4, Name = "Database", CreatedAt = DateTime.UtcNow, IsDeleted = false },
                new Department { Id = 5, Name = "Fullstack", CreatedAt = DateTime.UtcNow, IsDeleted = false }
            );

            // Soft delete filtresini buraya da eklemelisin
            builder.HasQueryFilter(d => !d.IsDeleted);
        }
    }
}