﻿using Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Infrastructure.Configurations
{
    internal class EmployeeConfiguration : IEntityTypeConfiguration<Employee>
    {
        public void Configure(EntityTypeBuilder<Employee> builder)
        {
            // DÜZELTME 1: Tablo ismindeki yazım hatası giderildi (Employess -> Employees)
            builder.ToTable("Employees");

            builder.HasKey(e => e.Id);

            // FullName veritabanına kaydedilmeyecek, sadece kod tarafında hesaplanacak
            builder.Ignore(e => e.FullName);

            builder.Property(e => e.FirstName)
                   .IsRequired()
                   .HasMaxLength(100);

            builder.Property(e => e.LastName)
                   .IsRequired()
                   .HasMaxLength(100);

            // DÜZELTME 2: SQL Server'da Email alanı için Unique Index eklemek performansı artırır
            builder.Property(e => e.Email)
                   .IsRequired()
                   .HasMaxLength(150);

            builder.HasIndex(e => e.Email).IsUnique();

            // Soft delete filtresi
            builder.HasQueryFilter(e => !e.IsDeleted);

            // İlişki yapılandırması
            builder.HasOne(e => e.Department)
                   .WithMany(d => d.Employees)
                   .HasForeignKey(e => e.DepartmentId)
                   .OnDelete(DeleteBehavior.Restrict);
            // SQL Server'da Restrict, bağlı personel varken departmanın silinmesini engeller.
        }
    }
}