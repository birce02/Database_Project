﻿using Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Infrastructure.Configurations
{
    public class InternConfiguration : IEntityTypeConfiguration<Intern>
    {
        public void Configure(EntityTypeBuilder<Intern> builder)
        {
            builder.ToTable("Interns");

            builder.HasKey(s => s.Id);

            // Veritabanında yer kaplamaması için FullName'i ignore ediyoruz
            builder.Ignore(s => s.FullName);

            builder.Property(s => s.FirstName)
                   .IsRequired()
                   .HasMaxLength(100);

            builder.Property(s => s.LastName)
                   .IsRequired()
                   .HasMaxLength(100);

            // GÜNCELLEME: SQL Server'da Email alanı için Unique Index eklenmesi önerilir
            builder.Property(s => s.Email)
                   .IsRequired()
                   .HasMaxLength(150);

            builder.HasIndex(s => s.Email).IsUnique();

            builder.Property(s => s.Phone)
                   .HasMaxLength(20);

            builder.Property(s => s.StudentNumber)
                   .HasMaxLength(50);

            // Soft delete filtresi
            builder.HasQueryFilter(s => s.IsDeleted == false);

            // İlişki Yapılandırması
            builder.HasOne(s => s.University)
                   .WithMany(u => u.Students)
                   .HasForeignKey(s => s.UniversityId)
                   .OnDelete(DeleteBehavior.Restrict);
            // SQL Server'da Restrict, bağlı stajyer varken üniversitenin silinmesini engeller.
        }
    }
}