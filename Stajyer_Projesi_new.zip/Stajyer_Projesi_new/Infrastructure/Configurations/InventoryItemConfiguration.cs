﻿using Domain.Entities;
using Domain.Enums;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;

namespace Infrastructure.Configurations
{
    public class InventoryItemConfiguration : IEntityTypeConfiguration<InventoryItem>
    {
        public void Configure(EntityTypeBuilder<InventoryItem> builder)
        {
            builder.ToTable("InventoryItems");

            builder.HasKey(i => i.Id);

            builder.Property(i => i.ItemCode)
                   .IsRequired()
                   .HasMaxLength(100);

            builder.Property(i => i.Category)
                   .IsRequired()
                   .HasMaxLength(100);

            builder.Property(i => i.Brand).HasMaxLength(100);

            builder.Property(i => i.Model)
                   .HasMaxLength(200);

            builder.HasIndex(i => i.ItemCode).IsUnique();

            builder.Property(i => i.Status)
                   .HasConversion<string>()
                   .HasMaxLength(50)
                   .IsRequired()
                   .HasDefaultValue(ItemStatus.Available);

            // GÜNCELLEME: SQL Server "timestamptz" desteklemez. 
            // datetime2 en hassas ve önerilen formattır.
            builder.Property(i => i.PurchaseDate).HasColumnType("datetime2");
            builder.Property(i => i.WarrantyEndDate).HasColumnType("datetime2");

            builder.Property<byte[]>("RowVersion").IsRowVersion();

            builder.Property(i => i.Notes).HasMaxLength(2000);

            builder.Property(i => i.SerialNumber).HasMaxLength(100);

            // soft delete filtresi
            builder.HasQueryFilter(i => !i.IsDeleted);
        }
    }
}