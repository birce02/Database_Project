﻿using Application.Interfaces;
using Domain.Entities;
using Domain.Enums;
using Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using System.Linq;

namespace Infrastructure.Repositories
{
    public class InventoryItemRepository : GenericRepository<InventoryItem>, IInventoryItemRepository
    {
        public InventoryItemRepository(AppDbContext context) : base(context) { }

        public IQueryable<InventoryItem> GetAvailableItems()
        {
            // GÜVENLİ LINQ: Sadece ItemStatus Enum'u 'Available' olanları filtrele
            return _context.InventoryItems
                .Where(i => i.Status == ItemStatus.Available)
                .AsNoTracking();
        }
    }
}