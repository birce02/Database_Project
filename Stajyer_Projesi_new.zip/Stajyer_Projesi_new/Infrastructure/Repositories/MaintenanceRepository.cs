﻿using Application.Interfaces;
using Domain.Entities;
using Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using System.Linq;

namespace Infrastructure.Repositories
{
    public class MaintenanceRepository : GenericRepository<Maintenance>, IMaintenanceRepository
    {
        public MaintenanceRepository(AppDbContext context) : base(context)
        {
        }

        // 1. CİHAZ ID'SİNE GÖRE BAKIM GEÇMİŞİ (LINQ)
        public IQueryable<Maintenance> GetByInventoryItemId(int inventoryItemId)
        {
            return _context.Maintenances
                // İlişkili cihaz bilgisini dahil et
                .Include(m => m.InventoryItem)
                // Cihaz ID'sine göre filtrele
                .Where(m => m.InventoryItemId == inventoryItemId)
                // HATA GİDERİLDİ: ReportedAt alanına göre sırala
                .OrderByDescending(m => m.ReportedAt)
                .AsNoTracking();
        }

        // 2. TÜM BAKIM KAYITLARI (LINQ)
        public IQueryable<Maintenance> GetAllWithDetails()
        {
            return _context.Maintenances
                // İlişkili cihaz bilgisini dahil et
                .Include(m => m.InventoryItem)
                // HATA GİDERİLDİ: ReportedAt alanına göre sırala
                .OrderByDescending(m => m.ReportedAt)
                .AsNoTracking();
        }
    }
}