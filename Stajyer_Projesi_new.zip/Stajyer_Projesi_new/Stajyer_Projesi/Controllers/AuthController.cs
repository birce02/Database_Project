﻿using Application.Common;
using Application.DTOs.Auth;
using Application.Services.Interfaces;
using Domain.Entities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Google.Apis.Auth; // Google Kütüphanesi Eklendi

namespace API.Controllers
{
    [Route("api/auth")]
    [ApiController]
    public class AuthController : CustomBaseController
    {
        private readonly IAuthService _authService;
        private readonly ITokenService _tokenService; // Token üretmek için eklendi

        // Constructor güncellendi: ITokenService eklendi
        public AuthController(IAuthService authService, ITokenService tokenService)
        {
            _authService = authService;
            _tokenService = tokenService;
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginDto loginDto)
        {
            var response = await _authService.LoginAsync(loginDto);
            if (response.IsSuccessful)
            {
                return Ok(new { Token = response.Data });
            }
            return CreateActionResult(response);
        }

        [Authorize(Roles = "User,Admin")]
        [HttpGet("me")]
        public async Task<IActionResult> GetMe()
        {
            var userName = User.Identity?.Name;
            var response = await _authService.GetMeAsync(userName);
            return CreateActionResult(response);
        }

        // [Authorize(Roles = "Admin")]
        [HttpPost("create-user")]
        public async Task<IActionResult> CreateUser([FromBody] RegisterDto registerDto)
        {
            var response = await _authService.CreateUserAsync(registerDto);
            return CreateActionResult(response);
        }

        [Authorize(Roles = "Admin")]
        [HttpDelete("delete-user/{id}")]
        public async Task<IActionResult> DeleteUser(int id)
        {
            var response = await _authService.DeleteUserAsync(id);
            return CreateActionResult(response);
        }

        [HttpPost("google-login")]
        public async Task<IActionResult> GoogleLogin([FromBody] GoogleLoginDto googleLoginDto)
        {
            try
            {
                // 1. Google Ayarları ve ID Doğrulama
                var settings = new GoogleJsonWebSignature.ValidationSettings()
                {
                    // Senin verdiğin Client ID buraya eklendi
                    Audience = new List<string>() { "800006543932-7rus52bh5jeb78pa1qq5tvuu9dv3m6ni.apps.googleusercontent.com" }
                };

                // Google Token'ını doğrula
                var payload = await GoogleJsonWebSignature.ValidateAsync(googleLoginDto.IdToken, settings);

                // 2. Bu mail adresi veritabanında var mı?
                var userResponse = await _authService.GetMeAsync(payload.Email);

                if (!userResponse.IsSuccessful || userResponse.Data == null)
                {
                    return BadRequest("Bu Google hesabıyla sistemde kayıtlı kullanıcı bulunamadı.");
                }

                // 3. Kullanıcı Bulundu -> Token Üretelim
                var appUser = userResponse.Data;

                // TokenService'in beklediği Employee formatına çeviriyoruz
                var tempEmployee = new Employee
                {
                    Id = appUser.Id,
                    FirstName = appUser.Employee?.FirstName ?? appUser.UserName, // Varsa adını, yoksa maili al
                    LastName = appUser.Employee?.LastName ?? "",
                    Email = appUser.Email
                };

                var roles = new List<string> { appUser.Role };

                // Gerçek JWT Token oluşturuluyor
                var token = _tokenService.CreateToken(tempEmployee, roles);

                // 4. Token'ı Frontend'e dön
                return Ok(new { Token = token });
            }
            catch (Exception ex)
            {
                // Hata durumunda (Token geçersizse veya başka sorun varsa)
                return BadRequest("Google Giriş Hatası: " + ex.Message);
            }
        }
    }
}