﻿using Application.DTOs.Employee;
using Application.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Application.Common;

namespace API.Controllers
{
    [Route("api/employees")]
    [ApiController]
    public class EmployeeController : CustomBaseController
    {
        private readonly IEmployeeService _service;

        public EmployeeController(IEmployeeService service)
        {
            _service = service;
        }

        [HttpGet]
        [Authorize(Roles = "Admin,User")]
        public async Task<IActionResult> GetAll()
        {
            return CreateActionResult(await _service.GetAllAsync());
        }

        [HttpGet("{id}")]
        [Authorize(Roles = "Admin,User")]
        public async Task<IActionResult> GetById(int id)
        {
            return CreateActionResult(await _service.GetByIdAsync(id));
        }

        [HttpGet("by-email")]
        [Authorize(Roles = "Admin,User")]
        public async Task<IActionResult> GetByEmail([FromQuery] string email)
        {
            // GetByEmailAsync metodu Service'de Response dönmüyorsa (Task<Dto?> dönüyorsa) 
            // burası farklı olabilir. Ama GenericService yapısına geçtiysen Response dönüyordur.
            // Eğer hata alırsan burayı kontrol et.
            // Şimdilik Generic yapıya uyumlu varsayıyorum:
            // Eğer Service Task<Dto> dönüyorsa: return CreateActionResult(Response<Dto>.Success(data, 200));

            // EmployeeService içinde GetByEmailAsync'i Response<T> dönecek şekilde güncellemediysek
            // manuel sarmalama gerekebilir. Ama hedefimiz her yerin Response dönmesi.

            // Şimdilik servisin eski usul (data) döndüğünü varsayarak sarmalıyorum:
            var data = await _service.GetByEmailAsync(email);
            return CreateActionResult(Response<EmployeeListDto>.Success(data, 200));
        }

        [HttpGet("by-department/{departmentId}")]
        [Authorize(Roles = "Admin,User")]
        public async Task<IActionResult> GetByDepartment(int departmentId)
        {
            // Servisin eski usul (IEnumerable) döndüğünü varsayarak sarmalıyorum:
            var data = await _service.GetByDepartmentIdAsync(departmentId);
            return CreateActionResult(Response<IEnumerable<EmployeeListDto>>.Success(data, 200));
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Create([FromBody] EmployeeCreateDto dto)
        {
            return CreateActionResult(await _service.CreateAsync(dto));
        }

        [HttpPut("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Update(int id, [FromBody] EmployeeUpdateDto dto)
        {
            return CreateActionResult(await _service.UpdateAsync(id, dto));
        }

        [HttpDelete("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Delete(int id)
        {
            return CreateActionResult(await _service.DeleteAsync(id));
        }
    }
}