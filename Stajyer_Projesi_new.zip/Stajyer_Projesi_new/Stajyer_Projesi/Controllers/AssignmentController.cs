﻿using Application.DTOs.Assignment;
using Application.DTOs.Maintenance;
using Application.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace API.Controllers
{
    [Route("api/assignments")]
    [ApiController]
    public class AssignmentController : CustomBaseController
    {
        private readonly IAssignmentService _service;

        public AssignmentController(IAssignmentService service)
        {
            _service = service;
        }

        [HttpGet]
        [Authorize(Roles = "Admin,User")]
        public async Task<IActionResult> GetAll()
        {
            return CreateActionResult(await _service.GetAllAsync());
        }

        [HttpGet("{id}")]
        [Authorize(Roles = "Admin,User")]
        public async Task<IActionResult> GetById(int id)
        {
            return CreateActionResult(await _service.GetByIdAsync(id));
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Create(AssignmentCreateDto dto)
        {
            return CreateActionResult(await _service.CreateAsync(dto));
        }

        [HttpPost("return")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Return(AssignmentReturnDto dto)
        {
            return CreateActionResult(await _service.ReturnAsync(dto));
        }

        [HttpPost("maintenance")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> CreateMaintenance(MaintenanceCreateDto dto)
        {
            return CreateActionResult(await _service.CreateMaintenanceAsync(dto));
        }

        [HttpPut("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Update(int id, AssignmentUpdateDto dto)
        {
            return CreateActionResult(await _service.UpdateAsync(id, dto));
        }

        [HttpDelete("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Delete(int id)
        {
            return CreateActionResult(await _service.DeleteAsync(id));
        }

        [HttpGet("by-employee/{employeeId}")]
        [Authorize(Roles = "Admin,User")]
        public async Task<IActionResult> ByEmployee(int employeeId)
        {
            return CreateActionResult(await _service.GetByEmployeeIdAsync(employeeId));
        }

        [HttpGet("by-intern/{internId}")]
        [Authorize(Roles = "Admin,User")]
        public async Task<IActionResult> ByIntern(int internId)
        {
            return CreateActionResult(await _service.GetByInternIdAsync(internId));
        }
    }
}