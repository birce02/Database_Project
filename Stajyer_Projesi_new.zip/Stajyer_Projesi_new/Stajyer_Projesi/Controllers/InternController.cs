﻿using Application.DTOs.Intern;
using Application.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace API.Controllers
{
    [Route("api/interns")]
    [ApiController]
    public class InternController : CustomBaseController
    {
        private readonly IInternService _service;

        public InternController(IInternService service)
        {
            _service = service;
        }

        [HttpGet]
        [Authorize(Roles = "Admin,User")]
        public async Task<IActionResult> GetAll()
        {
            // DÜZELTME: Service zaten Response dönüyor. Tekrar sarmalama!
            return CreateActionResult(await _service.GetAllWithDetailsAsync());
        }

        [HttpGet("{id}")]
        [Authorize(Roles = "Admin,User")]
        public async Task<IActionResult> GetById(int id)
        {
            return CreateActionResult(await _service.GetByIdAsync(id));
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Create([FromBody] InternCreateDto dto)
        {
            return CreateActionResult(await _service.CreateAsync(dto));
        }

        [HttpPut("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Update(int id, [FromBody] InternUpdateDto dto)
        {
            return CreateActionResult(await _service.UpdateAsync(id, dto));
        }

        [HttpDelete("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Delete(int id)
        {
            return CreateActionResult(await _service.DeleteAsync(id));
        }
    }
}