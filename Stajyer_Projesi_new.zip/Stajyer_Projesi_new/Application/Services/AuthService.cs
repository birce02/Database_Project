﻿using Application.Common;
using Application.DTOs.Auth;
using Application.Interfaces;
using Application.Services.Interfaces;
using Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace Application.Services
{
    public class AuthService : IAuthService
    {
        private readonly IUnitOfWork _uow;
        private readonly ITokenService _tokenService;
        private readonly IEmailService _emailService; 

        
        public AuthService(IUnitOfWork uow, ITokenService tokenService, IEmailService emailService)
        {
            _uow = uow;
            _tokenService = tokenService;
            _emailService = emailService;
        }

        public async Task<Response<string>> LoginAsync(LoginDto loginDto)
        {
            var appUser = await _uow.AppUsers
                .Where(u => u.UserName == loginDto.UserName && u.PasswordHash == loginDto.Password)
                .Include(u => u.Employee)
                .FirstOrDefaultAsync();

            if (appUser == null)
                return Response<string>.Fail("Kullanıcı adı veya şifre yanlış", 401, true);

            var tempEmployee = new Employee
            {
                Id = appUser.Id,
                FirstName = appUser.Employee?.FirstName ?? appUser.UserName,
                LastName = appUser.Employee?.LastName ?? "",
                Email = appUser.Email
            };

            var roles = new List<string> { appUser.Role };
            var token = _tokenService.CreateToken(tempEmployee, roles);

            return Response<string>.Success(token, 200);
        }

        public async Task<Response<AppUser>> CreateUserAsync(RegisterDto registerDto)
        {
            // Email Kontrolü
            var exists = await _uow.AppUsers.AnyAsync(x => x.Email == registerDto.Email);
            if (exists) return Response<AppUser>.Fail("Bu email zaten kayıtlı.", 400, true);

            var newUser = new AppUser
            {
                Email = registerDto.Email,
                UserName = registerDto.Email,
                Role = registerDto.Role,
                PasswordHash = registerDto.Password,
            };

            await _uow.AppUsers.AddAsync(newUser);
            await _uow.CommitAsync(); // Önce veritabanına kaydet

            // 3. EKLENDİ: Kayıt başarılıysa Mail Gönder
            try
            {
                string mailKonu = "Stajyer Takip Sistemi - Hoşgeldiniz";
                string mailIcerik = $@"
                    <h3>Merhaba,</h3>
                    <p>Sisteme kaydınız başarıyla oluşturulmuştur.</p>
                    <p><strong>Kullanıcı Adı:</strong> {newUser.Email}</p>
                    <p><strong>Şifre:</strong> {registerDto.Password}</p>
                    <br>
                    <p>İyi çalışmalar dileriz.</p>";

                // await kullanmıyoruz veya try-catch içine alıyoruz ki mail atamazsa bile kayıt iptal olmasın
                await _emailService.SendEmailAsync(newUser.Email, mailKonu, mailIcerik);
            }
            catch
            {
                // Mail gönderilemezse loglama yapılabilir ama kullanıcıya hata dönmeye gerek yok.
            }

            return Response<AppUser>.Success(newUser, 201);
        }

        public async Task<Response<NoContent>> DeleteUserAsync(int id)
        {
            var user = await _uow.AppUsers.GetByIdAsync(id);
            if (user == null) return Response<NoContent>.Fail("Kullanıcı bulunamadı", 404, true);

            _uow.AppUsers.Remove(user);
            await _uow.CommitAsync();

            return Response<NoContent>.Success(204);
        }

        public async Task<Response<AppUser>> GetMeAsync(string userName)
        {
            var appUser = await _uow.AppUsers
                .Where(u => u.UserName == userName)
                .Include(u => u.Employee)
                .FirstOrDefaultAsync();

            if (appUser == null) return Response<AppUser>.Fail("Kullanıcı bulunamadı", 404, true);

            return Response<AppUser>.Success(appUser, 200);
        }
    }
}